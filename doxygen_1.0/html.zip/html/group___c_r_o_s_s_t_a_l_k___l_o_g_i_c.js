var group___c_r_o_s_s_t_a_l_k___l_o_g_i_c =
[
    [ "CROSSTALK_WINDOW_MS", "group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html#ga470f772b7edfc2ef3662a5cf749c3843", null ],
    [ "HIGH_VELOCITY_THRESHOLD", "group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html#gae85be5266faad0b7b6e2dd9ba5a0bd54", null ],
    [ "lastHighVelocityMidiTime", "group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html#ga5360cd23c27b61439dd7c76499a15c0f", null ],
    [ "LOW_VELOCITY_DISCARD_THRESHOLD", "group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html#ga1c5777fa13b5071e6f0c711bb92c33ef", null ]
];