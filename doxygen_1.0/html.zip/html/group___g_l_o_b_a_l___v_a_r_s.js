var group___g_l_o_b_a_l___v_a_r_s =
[
    [ "aroCaixaPlaying", "group___g_l_o_b_a_l___v_a_r_s.html#ga5ca4737bb7fedb45c774da152d167a06", null ],
    [ "ataqueBordaPlaying", "group___g_l_o_b_a_l___v_a_r_s.html#gab5b73f8411b09442c3ed31af991e5aab", null ],
    [ "ataqueCupulaPlaying", "group___g_l_o_b_a_l___v_a_r_s.html#ga9a652ad7c58f62204f5054e7c07bde5e", null ],
    [ "caixaPlaying", "group___g_l_o_b_a_l___v_a_r_s.html#ga78e2b072085d2c0bd38c3758837f3e48", null ],
    [ "chimbalClosedSoundPlaying", "group___g_l_o_b_a_l___v_a_r_s.html#gad18520bcc92b41a90b36fb0f326fc178", null ],
    [ "chimbalOpenSoundPlaying", "group___g_l_o_b_a_l___v_a_r_s.html#gaf517c0e86dee64f44683a7287eb3eb21", null ],
    [ "conducaoBordaPlaying", "group___g_l_o_b_a_l___v_a_r_s.html#gad4d0a68de61efa0586081f7ba8a7ff2e", null ],
    [ "conducaoCupulaPlaying", "group___g_l_o_b_a_l___v_a_r_s.html#gae3725920797c88189df0c99908efa6f2", null ],
    [ "lastPedalChimbalState", "group___g_l_o_b_a_l___v_a_r_s.html#ga62870cab3c4a72a6214fee3c4883bae5", null ],
    [ "peakFoundTime", "group___g_l_o_b_a_l___v_a_r_s.html#ga9a5650ff5dcf1d294aadb8b9795d652b", null ],
    [ "peakSensorValues", "group___g_l_o_b_a_l___v_a_r_s.html#ga98f3e3afa08896f328a4bb41e4388fb1", null ],
    [ "pedalChimbalState", "group___g_l_o_b_a_l___v_a_r_s.html#gab74fcd6a275c5851851a6339dc0c5270", null ],
    [ "retriggerThresholdInitialDecay", "group___g_l_o_b_a_l___v_a_r_s.html#gab6e7a2b0f39587189f71c324481ff2fd", null ]
];