var group___i_n_i_c_i_a_l_i_z_a_c_a_o =
[
    [ "setup", "group___i_n_i_c_i_a_l_i_z_a_c_a_o.html#ga4fc01d736fe50cf5b977f755b675f11d", null ]
];