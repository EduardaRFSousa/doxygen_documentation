var group___m_a_i_n___l_o_o_p =
[
    [ "Processamento dos Pads Dual-Zone", "group___l_o_o_p___p_a_d_s___d_u_a_l___z_o_n_e.html", null ],
    [ "Processamento dos Pads Simples", "group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html", null ]
];