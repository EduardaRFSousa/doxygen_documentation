var group___p_a_d___i_n_d_i_c_e_s =
[
    [ "ARO_CAIXA_PAD", "group___p_a_d___i_n_d_i_c_e_s.html#ga2f9a89351c508b501aac2828229b1c5b", null ],
    [ "ATAQUE_BORDA_PAD", "group___p_a_d___i_n_d_i_c_e_s.html#ga5c4efc194090e5130391e570d0e089e6", null ],
    [ "ATAQUE_CUPULA_PAD", "group___p_a_d___i_n_d_i_c_e_s.html#gabee8e78127f6200d9e96fc367b3986b3", null ],
    [ "BUMBO_PAD", "group___p_a_d___i_n_d_i_c_e_s.html#gaa64dee83c3d1ef4e47c7b5728c6999a6", null ],
    [ "CAIXA_PAD", "group___p_a_d___i_n_d_i_c_e_s.html#ga9491c627053523698b9d085db3c03004", null ],
    [ "CHIMBAL_PAD", "group___p_a_d___i_n_d_i_c_e_s.html#gafb0afbcf817d6b442f37ad564b6bd3e7", null ],
    [ "CONDUCAO_BORDA_PAD", "group___p_a_d___i_n_d_i_c_e_s.html#gae394afaac804a8081275dcf497c9ab48", null ],
    [ "CONDUCAO_CUPULA_PAD", "group___p_a_d___i_n_d_i_c_e_s.html#gac675a902a09ce775368c7d5f8e212e31", null ],
    [ "NUM_PADS", "group___p_a_d___i_n_d_i_c_e_s.html#gaca96ac49d1491394b242ee8757b44254", null ],
    [ "SURDO_PAD", "group___p_a_d___i_n_d_i_c_e_s.html#ga09dcc6bec1b3b4b9f552d325a96d8793", null ],
    [ "TOM1_PAD", "group___p_a_d___i_n_d_i_c_e_s.html#gaaa86e092910098a834d1f519f42ccffa", null ],
    [ "TOM2_PAD", "group___p_a_d___i_n_d_i_c_e_s.html#ga03f6530e0e09cdec3d89dccfd7b94fb2", null ]
];