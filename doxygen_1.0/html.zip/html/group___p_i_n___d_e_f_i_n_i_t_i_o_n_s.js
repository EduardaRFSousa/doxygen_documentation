var group___p_i_n___d_e_f_i_n_i_t_i_o_n_s =
[
    [ "PEDAL_CHIMBAL_PIN", "group___p_i_n___d_e_f_i_n_i_t_i_o_n_s.html#ga126f33e22984f9a50964dbf49ead4f2c", null ],
    [ "piezoPin", "group___p_i_n___d_e_f_i_n_i_t_i_o_n_s.html#gaefc4444b8b85ec6e596808c7987dbeb6", null ]
];