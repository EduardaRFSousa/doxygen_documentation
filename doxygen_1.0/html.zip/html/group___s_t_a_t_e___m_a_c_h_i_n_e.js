var group___s_t_a_t_e___m_a_c_h_i_n_e =
[
    [ "PadState", "group___s_t_a_t_e___m_a_c_h_i_n_e.html#gac1e95534b090e69a8215c8e1a12b42b6", [
      [ "PAD_STATE_IDLE", "group___s_t_a_t_e___m_a_c_h_i_n_e.html#ggac1e95534b090e69a8215c8e1a12b42b6aeed3f11c29100a3fb8069ee800b27202", null ],
      [ "PAD_STATE_PEAK_DETECTION", "group___s_t_a_t_e___m_a_c_h_i_n_e.html#ggac1e95534b090e69a8215c8e1a12b42b6a89c1f306de78ed29c4bca4922d9435f3", null ],
      [ "PAD_STATE_SILENT_DEBOUNCE", "group___s_t_a_t_e___m_a_c_h_i_n_e.html#ggac1e95534b090e69a8215c8e1a12b42b6aac97fa3f2fa196298ff65f634402e8e0", null ],
      [ "PAD_STATE_REPIQUE_CHECK", "group___s_t_a_t_e___m_a_c_h_i_n_e.html#ggac1e95534b090e69a8215c8e1a12b42b6a1e510797d0d276253e099ae65af9f37b", null ],
      [ "PAD_STATE_CHOKE_CONFIRMATION", "group___s_t_a_t_e___m_a_c_h_i_n_e.html#ggac1e95534b090e69a8215c8e1a12b42b6a5a2c6d1262fc219aa6943a051d5c0a02", null ]
    ] ],
    [ "CHOKE_CONFIRMATION_TIME_MS", "group___s_t_a_t_e___m_a_c_h_i_n_e.html#gaf26f97ba8aa55dd96f1b48450332d939", null ],
    [ "padState", "group___s_t_a_t_e___m_a_c_h_i_n_e.html#ga086ea7d973b58f48962f45aaec031e34", null ],
    [ "REPIQUE_CHECK_MS", "group___s_t_a_t_e___m_a_c_h_i_n_e.html#ga7c30ff43ab5f6607b8c4b3a0a38426b7", null ],
    [ "SILENT_DEBOUNCE_MS", "group___s_t_a_t_e___m_a_c_h_i_n_e.html#ga0b463c7129b9d5d22d9631e30de7273f", null ],
    [ "stateChangeTime", "group___s_t_a_t_e___m_a_c_h_i_n_e.html#gababce2a25b964d94ef833ca0661eddfd", null ]
];