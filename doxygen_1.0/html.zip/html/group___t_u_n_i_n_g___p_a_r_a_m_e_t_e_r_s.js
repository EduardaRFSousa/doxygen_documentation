var group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s =
[
    [ "gainFactor", "group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#ga40bcf8e1f2a66ce1d6af7dff28c6984d", null ],
    [ "maxVelocity", "group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#ga62b91e477ed9c518ba9c668bd1556168", null ],
    [ "minVelocity", "group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#gabc72625141411c40da3baee3dc0cbe24", null ],
    [ "PEAK_DETECTION_WINDOW_MS", "group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#ga8ef00707786b3b6f41d979eaa0004ed6", null ],
    [ "RETRIGGER_MIN_MULTIPLIER", "group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#ga47982291ef6338fb259fe5852d425caa", null ],
    [ "retriggerThreshold", "group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#gaf833580d242e7e6444616aa827b57791", null ],
    [ "threshold", "group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#ga22cd61e2f53fcc6af27820ced906d91d", null ]
];