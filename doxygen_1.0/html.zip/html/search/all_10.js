var searchData=
[
  ['threshold_0',['threshold',['../group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#ga22cd61e2f53fcc6af27820ced906d91d',1,'main.c']]],
  ['tom1_5fpad_1',['TOM1_PAD',['../group___p_a_d___i_n_d_i_c_e_s.html#gaaa86e092910098a834d1f519f42ccffa',1,'main.c']]],
  ['tom2_5fpad_2',['TOM2_PAD',['../group___p_a_d___i_n_d_i_c_e_s.html#ga03f6530e0e09cdec3d89dccfd7b94fb2',1,'main.c']]]
];
