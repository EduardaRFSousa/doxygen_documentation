var searchData=
[
  ['variáveis_20globais_20de_20estado_0',['Variáveis Globais de Estado',['../group___g_l_o_b_a_l___v_a_r_s.html',1,'']]],
  ['verificação_20de_20repique_20pad_5fstate_5frepique_5fcheck_20para_20pads_20simples_1',['Estado de Verificação de Repique (PAD_STATE_REPIQUE_CHECK) para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_STATE_REPIQUE_CHECK_SIMPLE',1,'']]]
];
