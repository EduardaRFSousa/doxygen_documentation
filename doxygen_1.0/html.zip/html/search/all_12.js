var searchData=
[
  ['zone_0',['Processamento dos Pads Dual-Zone',['../group___l_o_o_p___p_a_d_s___d_u_a_l___z_o_n_e.html',1,'']]]
];
