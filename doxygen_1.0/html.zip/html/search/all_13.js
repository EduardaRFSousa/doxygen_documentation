var searchData=
[
  ['índices_20dos_20pads_0',['Índices dos Pads',['../group___p_a_d___i_n_d_i_c_e_s.html',1,'']]]
];
