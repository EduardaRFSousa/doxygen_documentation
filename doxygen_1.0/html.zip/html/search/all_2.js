var searchData=
[
  ['caixa_5fpad_0',['CAIXA_PAD',['../group___p_a_d___i_n_d_i_c_e_s.html#ga9491c627053523698b9d085db3c03004',1,'main.c']]],
  ['caixaplaying_1',['caixaPlaying',['../group___g_l_o_b_a_l___v_a_r_s.html#ga78e2b072085d2c0bd38c3758837f3e48',1,'main.c']]],
  ['chimbal_5fpad_2',['CHIMBAL_PAD',['../group___p_a_d___i_n_d_i_c_e_s.html#gafb0afbcf817d6b442f37ad564b6bd3e7',1,'main.c']]],
  ['chimbalclosedsoundplaying_3',['chimbalClosedSoundPlaying',['../group___g_l_o_b_a_l___v_a_r_s.html#gad18520bcc92b41a90b36fb0f326fc178',1,'main.c']]],
  ['chimbalopensoundplaying_4',['chimbalOpenSoundPlaying',['../group___g_l_o_b_a_l___v_a_r_s.html#gaf517c0e86dee64f44683a7287eb3eb21',1,'main.c']]],
  ['choke_20pad_5fstate_5fchoke_5fconfirmation_20para_20pads_20simples_5',['Estado Choke (PAD_STATE_CHOKE_CONFIRMATION) para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_STATE_CHOKE_CONFIRMATION_SIMPLE',1,'']]],
  ['choke_5fconfirmation_5ftime_5fms_6',['CHOKE_CONFIRMATION_TIME_MS',['../group___s_t_a_t_e___m_a_c_h_i_n_e.html#gaf26f97ba8aa55dd96f1b48450332d939',1,'main.c']]],
  ['conducao_5fborda_5fpad_7',['CONDUCAO_BORDA_PAD',['../group___p_a_d___i_n_d_i_c_e_s.html#gae394afaac804a8081275dcf497c9ab48',1,'main.c']]],
  ['conducao_5fcupula_5fpad_8',['CONDUCAO_CUPULA_PAD',['../group___p_a_d___i_n_d_i_c_e_s.html#gac675a902a09ce775368c7d5f8e212e31',1,'main.c']]],
  ['conducaobordaplaying_9',['conducaoBordaPlaying',['../group___g_l_o_b_a_l___v_a_r_s.html#gad4d0a68de61efa0586081f7ba8a7ff2e',1,'main.c']]],
  ['conducaocupulaplaying_10',['conducaoCupulaPlaying',['../group___g_l_o_b_a_l___v_a_r_s.html#gae3725920797c88189df0c99908efa6f2',1,'main.c']]],
  ['crosstalk_11',['Lógica de Eliminação de Crosstalk',['../group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html',1,'']]],
  ['crosstalk_20para_20pads_20simples_12',['Lógica de Eliminação de Crosstalk para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_SIMPLE_CROSSTALK',1,'']]],
  ['crosstalk_5fwindow_5fms_13',['CROSSTALK_WINDOW_MS',['../group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html#ga470f772b7edfc2ef3662a5cf749c3843',1,'main.c']]]
];
