var searchData=
[
  ['lógica_20de_20eliminação_20de_20crosstalk_0',['Lógica de Eliminação de Crosstalk',['../group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html',1,'']]],
  ['lógica_20de_20eliminação_20de_20crosstalk_20para_20pads_20simples_1',['Lógica de Eliminação de Crosstalk para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_SIMPLE_CROSSTALK',1,'']]],
  ['lógica_20principal_20loop_2',['Lógica Principal (loop)',['../group___m_a_i_n___l_o_o_p.html',1,'']]],
  ['lasthighvelocitymiditime_3',['lastHighVelocityMidiTime',['../group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html#ga5360cd23c27b61439dd7c76499a15c0f',1,'main.c']]],
  ['lastpedalchimbalstate_4',['lastPedalChimbalState',['../group___g_l_o_b_a_l___v_a_r_s.html#ga62870cab3c4a72a6214fee3c4883bae5',1,'main.c']]],
  ['loop_5',['Lógica Principal (loop)',['../group___m_a_i_n___l_o_o_p.html',1,'']]],
  ['low_5fvelocity_5fdiscard_5fthreshold_6',['LOW_VELOCITY_DISCARD_THRESHOLD',['../group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html#ga1c5777fa13b5071e6f0c711bb92c33ef',1,'main.c']]]
];
