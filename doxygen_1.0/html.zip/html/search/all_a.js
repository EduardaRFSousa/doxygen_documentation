var searchData=
[
  ['máquina_20de_20estados_20e_20debounce_0',['Máquina de Estados e Debounce',['../group___s_t_a_t_e___m_a_c_h_i_n_e.html',1,'']]],
  ['main_2ec_1',['main.c',['../main_8c.html',1,'']]],
  ['maxvelocity_2',['maxVelocity',['../group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#ga62b91e477ed9c518ba9c668bd1556168',1,'main.c']]],
  ['midi_3',['Notas MIDI',['../group___m_i_d_i___n_o_t_e_s.html',1,'']]],
  ['midi_20para_20pads_20simples_4',['Envio de Nota MIDI para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_SIMPLE_MIDI_OUTPUT',1,'']]],
  ['midi_5fnote_5fchimbal_5fclosed_5',['MIDI_NOTE_CHIMBAL_CLOSED',['../group___m_i_d_i___n_o_t_e_s.html#ga7d30b7867fc45f7efcb52b7123668726',1,'main.c']]],
  ['midi_5fnote_5fchimbal_5fopen_6',['MIDI_NOTE_CHIMBAL_OPEN',['../group___m_i_d_i___n_o_t_e_s.html#ga689e0d767e0c0b72fcdc96768c13ebf7',1,'main.c']]],
  ['midi_5fnote_5fchimbal_5fpedal_7',['MIDI_NOTE_CHIMBAL_PEDAL',['../group___m_i_d_i___n_o_t_e_s.html#gade4854eacc35406262ba0ec9ca436dca',1,'main.c']]],
  ['midi_5fnote_5frimshot_8',['MIDI_NOTE_RIMSHOT',['../group___m_i_d_i___n_o_t_e_s.html#gaf8b87483fc69a22104741c211b70035b',1,'main.c']]],
  ['midinote_9',['midiNote',['../group___m_i_d_i___n_o_t_e_s.html#ga981fa46342483e4ee5c8ad38abbe557e',1,'main.c']]],
  ['midinoteoff_10',['midiNoteOff',['../main_8c.html#a62e42bf6dab59c063bd74f3d3fee16a8',1,'main.c']]],
  ['midinoteon_11',['midiNoteOn',['../main_8c.html#a0d23c69141dfd387fa7c57dfcf422a6f',1,'main.c']]],
  ['minvelocity_12',['minVelocity',['../group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#gabc72625141411c40da3baee3dc0cbe24',1,'main.c']]]
];
