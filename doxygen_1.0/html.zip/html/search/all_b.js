var searchData=
[
  ['nota_20midi_20para_20pads_20simples_0',['Envio de Nota MIDI para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_SIMPLE_MIDI_OUTPUT',1,'']]],
  ['notas_20midi_1',['Notas MIDI',['../group___m_i_d_i___n_o_t_e_s.html',1,'']]],
  ['num_5fpads_2',['NUM_PADS',['../group___p_a_d___i_n_d_i_c_e_s.html#gaca96ac49d1491394b242ee8757b44254',1,'main.c']]]
];
