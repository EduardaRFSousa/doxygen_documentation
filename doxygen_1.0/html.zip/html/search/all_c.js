var searchData=
[
  ['ocioso_20pad_5fstate_5fidle_20para_20pads_20simples_0',['Estado Ocioso (PAD_STATE_IDLE) para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_STATE_IDLE_SIMPLE',1,'']]]
];
