var searchData=
[
  ['repique_20pad_5fstate_5frepique_5fcheck_20para_20pads_20simples_0',['Estado de Verificação de Repique (PAD_STATE_REPIQUE_CHECK) para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_STATE_REPIQUE_CHECK_SIMPLE',1,'']]],
  ['repique_5fcheck_5fms_1',['REPIQUE_CHECK_MS',['../group___s_t_a_t_e___m_a_c_h_i_n_e.html#ga7c30ff43ab5f6607b8c4b3a0a38426b7',1,'main.c']]],
  ['resposta_2',['Parâmetros de Sensibilidade e Resposta',['../group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html',1,'']]],
  ['retrigger_5fmin_5fmultiplier_3',['RETRIGGER_MIN_MULTIPLIER',['../group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#ga47982291ef6338fb259fe5852d425caa',1,'main.c']]],
  ['retriggerthreshold_4',['retriggerThreshold',['../group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#gaf833580d242e7e6444616aa827b57791',1,'main.c']]],
  ['retriggerthresholdinitialdecay_5',['retriggerThresholdInitialDecay',['../group___g_l_o_b_a_l___v_a_r_s.html#gab6e7a2b0f39587189f71c324481ff2fd',1,'main.c']]]
];
