var searchData=
[
  ['midinoteoff_0',['midiNoteOff',['../main_8c.html#a62e42bf6dab59c063bd74f3d3fee16a8',1,'main.c']]],
  ['midinoteon_1',['midiNoteOn',['../main_8c.html#a0d23c69141dfd387fa7c57dfcf422a6f',1,'main.c']]]
];
