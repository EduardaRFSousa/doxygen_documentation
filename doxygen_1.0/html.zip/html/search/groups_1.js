var searchData=
[
  ['crosstalk_0',['Lógica de Eliminação de Crosstalk',['../group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html',1,'']]]
];
