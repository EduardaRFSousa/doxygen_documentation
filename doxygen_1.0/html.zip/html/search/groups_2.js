var searchData=
[
  ['de_20crosstalk_0',['Lógica de Eliminação de Crosstalk',['../group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html',1,'']]],
  ['de_20eliminação_20de_20crosstalk_1',['Lógica de Eliminação de Crosstalk',['../group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html',1,'']]],
  ['de_20estado_2',['Variáveis Globais de Estado',['../group___g_l_o_b_a_l___v_a_r_s.html',1,'']]],
  ['de_20estados_20e_20debounce_3',['Máquina de Estados e Debounce',['../group___s_t_a_t_e___m_a_c_h_i_n_e.html',1,'']]],
  ['de_20inicialização_20do_20arduino_4',['Função de inicialização do Arduino.',['../group___i_n_i_c_i_a_l_i_z_a_c_a_o.html',1,'']]],
  ['de_20pinos_5',['Definições de Pinos',['../group___p_i_n___d_e_f_i_n_i_t_i_o_n_s.html',1,'']]],
  ['de_20sensibilidade_20e_20resposta_6',['Parâmetros de Sensibilidade e Resposta',['../group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html',1,'']]],
  ['debounce_7',['Máquina de Estados e Debounce',['../group___s_t_a_t_e___m_a_c_h_i_n_e.html',1,'']]],
  ['definições_20de_20pinos_8',['Definições de Pinos',['../group___p_i_n___d_e_f_i_n_i_t_i_o_n_s.html',1,'']]],
  ['do_20arduino_9',['Função de inicialização do Arduino.',['../group___i_n_i_c_i_a_l_i_z_a_c_a_o.html',1,'']]],
  ['dos_20pads_10',['Índices dos Pads',['../group___p_a_d___i_n_d_i_c_e_s.html',1,'']]],
  ['dos_20pads_20dual_20zone_11',['Processamento dos Pads Dual-Zone',['../group___l_o_o_p___p_a_d_s___d_u_a_l___z_o_n_e.html',1,'']]],
  ['dos_20pads_20simples_12',['Processamento dos Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html',1,'']]],
  ['dual_20zone_13',['Processamento dos Pads Dual-Zone',['../group___l_o_o_p___p_a_d_s___d_u_a_l___z_o_n_e.html',1,'']]]
];
