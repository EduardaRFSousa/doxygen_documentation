var searchData=
[
  ['e_20debounce_0',['Máquina de Estados e Debounce',['../group___s_t_a_t_e___m_a_c_h_i_n_e.html',1,'']]],
  ['e_20resposta_1',['Parâmetros de Sensibilidade e Resposta',['../group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html',1,'']]],
  ['eliminação_20de_20crosstalk_2',['Lógica de Eliminação de Crosstalk',['../group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html',1,'']]],
  ['estado_3',['Variáveis Globais de Estado',['../group___g_l_o_b_a_l___v_a_r_s.html',1,'']]],
  ['estados_20e_20debounce_4',['Máquina de Estados e Debounce',['../group___s_t_a_t_e___m_a_c_h_i_n_e.html',1,'']]]
];
