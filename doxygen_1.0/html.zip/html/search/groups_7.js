var searchData=
[
  ['lógica_20de_20eliminação_20de_20crosstalk_0',['Lógica de Eliminação de Crosstalk',['../group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html',1,'']]],
  ['lógica_20principal_20loop_1',['Lógica Principal (loop)',['../group___m_a_i_n___l_o_o_p.html',1,'']]],
  ['loop_2',['Lógica Principal (loop)',['../group___m_a_i_n___l_o_o_p.html',1,'']]]
];
