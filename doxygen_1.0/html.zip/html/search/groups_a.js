var searchData=
[
  ['pads_0',['Índices dos Pads',['../group___p_a_d___i_n_d_i_c_e_s.html',1,'']]],
  ['pads_20dual_20zone_1',['Processamento dos Pads Dual-Zone',['../group___l_o_o_p___p_a_d_s___d_u_a_l___z_o_n_e.html',1,'']]],
  ['pads_20simples_2',['Processamento dos Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html',1,'']]],
  ['parâmetros_20de_20sensibilidade_20e_20resposta_3',['Parâmetros de Sensibilidade e Resposta',['../group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html',1,'']]],
  ['pinos_4',['Definições de Pinos',['../group___p_i_n___d_e_f_i_n_i_t_i_o_n_s.html',1,'']]],
  ['principal_20loop_5',['Lógica Principal (loop)',['../group___m_a_i_n___l_o_o_p.html',1,'']]],
  ['processamento_20dos_20pads_20dual_20zone_6',['Processamento dos Pads Dual-Zone',['../group___l_o_o_p___p_a_d_s___d_u_a_l___z_o_n_e.html',1,'']]],
  ['processamento_20dos_20pads_20simples_7',['Processamento dos Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html',1,'']]]
];
