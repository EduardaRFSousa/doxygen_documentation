var searchData=
[
  ['resposta_0',['Parâmetros de Sensibilidade e Resposta',['../group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html',1,'']]]
];
