var searchData=
[
  ['sensibilidade_20e_20resposta_0',['Parâmetros de Sensibilidade e Resposta',['../group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html',1,'']]],
  ['simples_1',['Processamento dos Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html',1,'']]]
];
