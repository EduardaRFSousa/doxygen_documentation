var searchData=
[
  ['variáveis_20globais_20de_20estado_0',['Variáveis Globais de Estado',['../group___g_l_o_b_a_l___v_a_r_s.html',1,'']]]
];
