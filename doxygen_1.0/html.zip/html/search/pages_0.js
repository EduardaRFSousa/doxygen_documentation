var searchData=
[
  ['choke_20pad_5fstate_5fchoke_5fconfirmation_20para_20pads_20simples_0',['Estado Choke (PAD_STATE_CHOKE_CONFIRMATION) para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_STATE_CHOKE_CONFIRMATION_SIMPLE',1,'']]],
  ['crosstalk_20para_20pads_20simples_1',['Lógica de Eliminação de Crosstalk para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_SIMPLE_CROSSTALK',1,'']]]
];
