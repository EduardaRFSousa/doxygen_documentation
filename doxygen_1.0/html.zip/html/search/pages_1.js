var searchData=
[
  ['de_20crosstalk_20para_20pads_20simples_0',['Lógica de Eliminação de Crosstalk para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_SIMPLE_CROSSTALK',1,'']]],
  ['de_20debounce_20silencioso_20pad_5fstate_5fsilent_5fdebounce_20para_20pads_20simples_1',['Estado de Debounce Silencioso (PAD_STATE_SILENT_DEBOUNCE) para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_STATE_SILENT_DEBOUNCE_SIMPLE',1,'']]],
  ['de_20detecção_20de_20pico_20pad_5fstate_5fpeak_5fdetection_20para_20pads_20simples_2',['Estado de Detecção de Pico (PAD_STATE_PEAK_DETECTION) para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_STATE_PEAK_DETECTION_SIMPLE',1,'']]],
  ['de_20eliminação_20de_20crosstalk_20para_20pads_20simples_3',['Lógica de Eliminação de Crosstalk para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_SIMPLE_CROSSTALK',1,'']]],
  ['de_20nota_20midi_20para_20pads_20simples_4',['Envio de Nota MIDI para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_SIMPLE_MIDI_OUTPUT',1,'']]],
  ['de_20pico_20pad_5fstate_5fpeak_5fdetection_20para_20pads_20simples_5',['Estado de Detecção de Pico (PAD_STATE_PEAK_DETECTION) para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_STATE_PEAK_DETECTION_SIMPLE',1,'']]],
  ['de_20repique_20pad_5fstate_5frepique_5fcheck_20para_20pads_20simples_6',['Estado de Verificação de Repique (PAD_STATE_REPIQUE_CHECK) para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_STATE_REPIQUE_CHECK_SIMPLE',1,'']]],
  ['de_20verificação_20de_20repique_20pad_5fstate_5frepique_5fcheck_20para_20pads_20simples_7',['Estado de Verificação de Repique (PAD_STATE_REPIQUE_CHECK) para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_STATE_REPIQUE_CHECK_SIMPLE',1,'']]],
  ['debounce_20silencioso_20pad_5fstate_5fsilent_5fdebounce_20para_20pads_20simples_8',['Estado de Debounce Silencioso (PAD_STATE_SILENT_DEBOUNCE) para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_STATE_SILENT_DEBOUNCE_SIMPLE',1,'']]],
  ['detecção_20de_20pico_20pad_5fstate_5fpeak_5fdetection_20para_20pads_20simples_9',['Estado de Detecção de Pico (PAD_STATE_PEAK_DETECTION) para Pads Simples',['../group___l_o_o_p___p_a_d_s___s_i_m_p_l_e_s.html#PAD_STATE_PEAK_DETECTION_SIMPLE',1,'']]]
];
