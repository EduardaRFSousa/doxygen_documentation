var searchData=
[
  ['tempo_20da_20última_20batida_20forte_0',['Atualização do tempo da última batida forte.',['../C:/Users/Educação/OneDrive/Área de Trabalho/doxygen/main.c#PAD_SIMPLE_LAST_HIGH_VELOCITY_UPDATE',1,'']]]
];
