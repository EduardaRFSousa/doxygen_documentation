var searchData=
[
  ['arocaixaplaying_0',['aroCaixaPlaying',['../group___g_l_o_b_a_l___v_a_r_s.html#ga5ca4737bb7fedb45c774da152d167a06',1,'main.c']]],
  ['ataquebordaplaying_1',['ataqueBordaPlaying',['../group___g_l_o_b_a_l___v_a_r_s.html#gab5b73f8411b09442c3ed31af991e5aab',1,'main.c']]],
  ['ataquecupulaplaying_2',['ataqueCupulaPlaying',['../group___g_l_o_b_a_l___v_a_r_s.html#ga9a652ad7c58f62204f5054e7c07bde5e',1,'main.c']]]
];
