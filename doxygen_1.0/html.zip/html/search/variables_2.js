var searchData=
[
  ['gainfactor_0',['gainFactor',['../group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#ga40bcf8e1f2a66ce1d6af7dff28c6984d',1,'main.c']]]
];
