var searchData=
[
  ['lasthighvelocitymiditime_0',['lastHighVelocityMidiTime',['../group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html#ga5360cd23c27b61439dd7c76499a15c0f',1,'main.c']]],
  ['lastpedalchimbalstate_1',['lastPedalChimbalState',['../group___g_l_o_b_a_l___v_a_r_s.html#ga62870cab3c4a72a6214fee3c4883bae5',1,'main.c']]],
  ['low_5fvelocity_5fdiscard_5fthreshold_2',['LOW_VELOCITY_DISCARD_THRESHOLD',['../group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html#ga1c5777fa13b5071e6f0c711bb92c33ef',1,'main.c']]]
];
