var searchData=
[
  ['maxvelocity_0',['maxVelocity',['../group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#ga62b91e477ed9c518ba9c668bd1556168',1,'main.c']]],
  ['midi_5fnote_5fchimbal_5fclosed_1',['MIDI_NOTE_CHIMBAL_CLOSED',['../group___m_i_d_i___n_o_t_e_s.html#ga7d30b7867fc45f7efcb52b7123668726',1,'main.c']]],
  ['midi_5fnote_5fchimbal_5fopen_2',['MIDI_NOTE_CHIMBAL_OPEN',['../group___m_i_d_i___n_o_t_e_s.html#ga689e0d767e0c0b72fcdc96768c13ebf7',1,'main.c']]],
  ['midi_5fnote_5fchimbal_5fpedal_3',['MIDI_NOTE_CHIMBAL_PEDAL',['../group___m_i_d_i___n_o_t_e_s.html#gade4854eacc35406262ba0ec9ca436dca',1,'main.c']]],
  ['midi_5fnote_5frimshot_4',['MIDI_NOTE_RIMSHOT',['../group___m_i_d_i___n_o_t_e_s.html#gaf8b87483fc69a22104741c211b70035b',1,'main.c']]],
  ['midinote_5',['midiNote',['../group___m_i_d_i___n_o_t_e_s.html#ga981fa46342483e4ee5c8ad38abbe557e',1,'main.c']]],
  ['minvelocity_6',['minVelocity',['../group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html#gabc72625141411c40da3baee3dc0cbe24',1,'main.c']]]
];
