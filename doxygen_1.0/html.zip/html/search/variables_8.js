var searchData=
[
  ['silent_5fdebounce_5fms_0',['SILENT_DEBOUNCE_MS',['../group___s_t_a_t_e___m_a_c_h_i_n_e.html#ga0b463c7129b9d5d22d9631e30de7273f',1,'main.c']]],
  ['statechangetime_1',['stateChangeTime',['../group___s_t_a_t_e___m_a_c_h_i_n_e.html#gababce2a25b964d94ef833ca0661eddfd',1,'main.c']]]
];
