var topics =
[
    [ "Índices dos Pads", "group___p_a_d___i_n_d_i_c_e_s.html", "group___p_a_d___i_n_d_i_c_e_s" ],
    [ "Definições de Pinos", "group___p_i_n___d_e_f_i_n_i_t_i_o_n_s.html", "group___p_i_n___d_e_f_i_n_i_t_i_o_n_s" ],
    [ "Notas MIDI", "group___m_i_d_i___n_o_t_e_s.html", "group___m_i_d_i___n_o_t_e_s" ],
    [ "Parâmetros de Sensibilidade e Resposta", "group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s.html", "group___t_u_n_i_n_g___p_a_r_a_m_e_t_e_r_s" ],
    [ "Máquina de Estados e Debounce", "group___s_t_a_t_e___m_a_c_h_i_n_e.html", "group___s_t_a_t_e___m_a_c_h_i_n_e" ],
    [ "Lógica de Eliminação de Crosstalk", "group___c_r_o_s_s_t_a_l_k___l_o_g_i_c.html", "group___c_r_o_s_s_t_a_l_k___l_o_g_i_c" ],
    [ "Variáveis Globais de Estado", "group___g_l_o_b_a_l___v_a_r_s.html", "group___g_l_o_b_a_l___v_a_r_s" ],
    [ "Função de inicialização do Arduino.", "group___i_n_i_c_i_a_l_i_z_a_c_a_o.html", "group___i_n_i_c_i_a_l_i_z_a_c_a_o" ],
    [ "Lógica Principal (loop)", "group___m_a_i_n___l_o_o_p.html", "group___m_a_i_n___l_o_o_p" ]
];